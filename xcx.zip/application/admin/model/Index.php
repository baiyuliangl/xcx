<?php
namespace app\admin\model;

use think\Model;

class Index extends Model
{

}