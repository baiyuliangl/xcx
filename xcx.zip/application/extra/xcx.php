<?php

return[
   'APPID' =>'wx047f5bd4ec964a03',
   'SECRET' =>'ec83fde34a893ea1f19b221ac3b47f92'
];
